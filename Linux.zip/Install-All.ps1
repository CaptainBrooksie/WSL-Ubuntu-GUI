

#Elevate PowerShell to Administrator

If (-NOT ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator))
{
  Start-Process powershell.exe "-File",('"{0}"' -f $MyInvocation.MyCommand.Path) -Verb RunAs
  exit
}

reg add "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\AppModelUnlock" /t REG_DWORD /f /v "AllowDevelopmentWithoutDevLicense" /d "1"

#Enables Windows Subsystem for Linux Feature

Enable-WindowsOptionalFeature -Online -FeatureName Microsoft-Windows-Subsystem-Linux -NoRestart

#Install Chocolately Package Manager

Set-ExecutionPolicy Bypass -Scope Process -Force; [System.Net.ServicePointManager]::SecurityProtocol = [System.Net.ServicePointManager]::SecurityProtocol -bor 3072; iex ((New-Object System.Net.WebClient).DownloadString('https://chocolatey.org/install.ps1'))


#Downloads Ubuntu

curl.exe https://cloud-images.ubuntu.com/releases/focal/release/ubuntu-20.04-server-cloudimg-amd64-wsl.rootfs.tar.gz --output Ubuntu2004.tar.gz

#Mounts Ubuntu

wsl --import Ubuntu-20.04 C:\MyInstallLocation Ubuntu2004.tar.gz

#Install vcxsrv from Choclately

choco install vcxsrv -y --force

#Launches Install-GUI bash script

Set-Location -Path C:\Linux

bash.exe Install-Gui.sh

.\Launch-GUI.ps1

Write-Host -NoNewLine 'Install Complete. Press any key to continue...';
$null = $Host.UI.RawUI.ReadKey('NoEcho,IncludeKeyDown');




