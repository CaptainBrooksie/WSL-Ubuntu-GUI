1. Extract Linux.zip to contents to C:\Linux
2. Run Install-All.ps1
3. Once complete Linux GUI will launch
4. Launch-GUI.ps1 can be used from now on to launch Linux GUI
