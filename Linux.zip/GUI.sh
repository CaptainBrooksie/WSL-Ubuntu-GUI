export DISPLAY=:0
export LIBGL_ALWAYS_INDIRECT=1
startlxde