#Open X Launch
./config.xlaunch

#Runs gui bash script
bash.exe gui.sh